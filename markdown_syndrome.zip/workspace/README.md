## Markdown Syndrome

i decided to write a markdown-html converter

how original.

### uses
``flask, python, html, css, md``

#### features in works:
1. input from __textarea__
2. processing in ``app.py``
3. output to __p__

#### features in plans:
1. input from ``input.md``
2. output to ``output.md`
3. syntax highliting with ``highlight.js``